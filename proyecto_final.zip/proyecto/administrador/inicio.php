<?php include("template/cabecera.php"); ?>

            <!-- MENSAJE DE BIENVENIDA AL USUARIO -->
            <div class="jumbotron">
                <h1 class="display-3">Bienvenido <?php echo $nombreUsuario; ?></h1>
                <p class="lead">Vamos a administrar nuestro sitio </p>
            </div>
            
<?php include("template/pie.php"); ?>