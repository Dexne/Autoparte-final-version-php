<?php include("template/cabecera.php"); ?>

<div class="jumbotron">
    <h1 class="display-3">ARCHIVO CLIENTES</h1>
    <a name="" id="" class="btn btn-primary" href="verClientes.php" role="button">Ver clientes</a>
    <a name="" id="" class="btn btn-primary" href="agregarClientes.php" role="button">Agregar clientes</a>
</div>

<?php include("template/pie.php"); ?>