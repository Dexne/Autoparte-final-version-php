<?php include("template/cabecera.php"); ?>

<div class="jumbotron">
    <h1 class="display-3">ARCHIVO EMPLEADOS</h1>
    <a name="" id="" class="btn btn-primary" href="verEmpleados.php" role="button">Ver empleados</a>
    <a name="" id="" class="btn btn-primary" href="agregarEmpleados.php" role="button">Agregar empleados</a>
</div>

<?php include("template/pie.php"); ?>