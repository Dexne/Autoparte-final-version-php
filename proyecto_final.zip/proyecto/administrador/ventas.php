<?php include("template/cabecera.php"); ?>

<div class="jumbotron">
    <h1 class="display-1">ARCHIVO VENTAS</h1>
    <a name="" id="" class="btn btn-primary" href="verVentas.php" role="button">Ver ventas</a>
    <a name="" id="" class="btn btn-primary" href="agregarVentas.php" role="button">Agregar venta</a>
</div>

<?php include("template/pie.php"); ?>