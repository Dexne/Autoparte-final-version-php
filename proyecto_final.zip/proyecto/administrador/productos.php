<?php include("template/cabecera.php"); ?>

<div class="jumbotron">
    <h1 class="display-3">ARCHIVO PRODUCTOS</h1>
    <a name="" id="" class="btn btn-primary" href="verProductos.php" role="button">Ver productos</a>
    <a name="" id="" class="btn btn-primary" href="agregarProductos.php" role="button">Agregar productos</a>
    <hr class="my-3">
</div>

<?php include("template/pie.php"); ?>